<!DOCTYPE html>
<html>
<head>
 <title>UKK KASIR</title>
 <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
 
 <div class="kotak_login">
 <p class="tulisan_login">Silahkan login</p>
 <?php 
    if(isset($_GET['pesan'])){
        if($_GET['pesan']=="gagal"){
            echo "<div class='alert'>Username dan Password tidak sesuai !</div>";
        }
    }
    ?>
 <form method="post" action="cek_login.php">
 <label>Username</label>
 <input type="text" name="username" class="form_login" placeholder="Username ..">
 
 <label>Password</label>
 <input type="password" name="password" class="form_login" placeholder="Password ..">
 
 <input type="submit" class="tombol_login" value="LOGIN">
 
 <br/>
 <br/>
 </form>
 
 </div>
 
 
</body>
</html>